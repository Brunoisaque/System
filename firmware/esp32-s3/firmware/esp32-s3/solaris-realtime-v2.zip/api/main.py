import asyncio
import json
import os
from datetime import datetime, timezone
from typing import Set

import paho.mqtt.client as mqtt
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from sqlalchemy import Column, DateTime, Float, Integer, String, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./telemetry.db")
MQTT_HOST = os.getenv("MQTT_HOST", "mqtt")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "solaris/telemetry")

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class Telemetry(Base):
    __tablename__ = "telemetry"
    id = Column(Integer, primary_key=True)
    device_id = Column(String(100), index=True, nullable=False)
    timestamp = Column(DateTime, index=True, nullable=False)
    temperature_c = Column(Float)
    humidity_pct = Column(Float)
    wifi_rssi = Column(Integer)
    free_heap = Column(Integer)

Base.metadata.create_all(engine)

app = FastAPI(title="Solaris Realtime API", version="2.0.0")
clients: Set[WebSocket] = set()

def mqtt_message(payload: dict):
    db = SessionLocal()
    try:
        row = Telemetry(
            device_id=str(payload.get("device_id", "unknown")),
            timestamp=datetime.now(timezone.utc),
            temperature_c=payload.get("temperature_c"),
            humidity_pct=payload.get("humidity_pct"),
            wifi_rssi=payload.get("wifi_rssi"),
            free_heap=payload.get("free_heap"),
        )
        db.add(row)
        db.commit()
    finally:
        db.close()

async def broadcast(payload: dict):
    dead = []
    message = json.dumps(payload)
    for ws in list(clients):
        try:
            await ws.send_text(message)
        except Exception:
            dead.append(ws)
    for ws in dead:
        clients.discard(ws)

def on_connect(client, userdata, flags, rc, properties=None):
    print("MQTT connected:", rc)
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        mqtt_message(payload)
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(broadcast(payload))
        except RuntimeError:
            pass
    except Exception as exc:
        print("Telemetry error:", exc)

mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

@app.on_event("startup")
async def startup():
    mqtt_client.connect(MQTT_HOST, MQTT_PORT, 60)
    mqtt_client.loop_start()

@app.on_event("shutdown")
async def shutdown():
    mqtt_client.loop_stop()
    mqtt_client.disconnect()

@app.get("/health")
def health():
    return {"status": "ok", "service": "solaris-realtime"}

@app.get("/telemetry/latest")
def latest(limit: int = 50):
    limit = max(1, min(limit, 500))
    db = SessionLocal()
    try:
        rows = db.query(Telemetry).order_by(Telemetry.id.desc()).limit(limit).all()
        return [
            {
                "device_id": r.device_id,
                "timestamp": r.timestamp.isoformat(),
                "temperature_c": r.temperature_c,
                "humidity_pct": r.humidity_pct,
                "wifi_rssi": r.wifi_rssi,
                "free_heap": r.free_heap,
            }
            for r in reversed(rows)
        ]
    finally:
        db.close()

@app.websocket("/ws/telemetry")
async def telemetry_ws(ws: WebSocket):
    await ws.accept()
    clients.add(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        clients.discard(ws)
    except Exception:
        clients.discard(ws)
