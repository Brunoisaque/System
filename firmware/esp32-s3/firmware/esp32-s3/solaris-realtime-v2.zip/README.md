# Solaris Realtime v2

Camada de persistência + WebSocket + dashboard.

## Arquitetura

ESP32-S3
  ↓ MQTT
Mosquitto
  ↓
FastAPI
  ├── SQLite
  └── WebSocket
        ↓
Dashboard

## Iniciar

```bash
docker compose up --build -d
```

API:
http://localhost:8000/health

Swagger:
http://localhost:8000/docs

Dashboard:
http://localhost:8080

MQTT:
```bash
mosquitto_sub -h localhost -t solaris/telemetry -v
```

## Observação

A configuração MQTT deste pacote é somente para laboratório local.
Para produção, use autenticação, TLS, firewall e não exponha a porta 1883 diretamente.

## Próximo módulo

OTA seguro do ESP32-S3 + sensores adicionais + autenticação MQTT + PostgreSQL/TimescaleDB.
