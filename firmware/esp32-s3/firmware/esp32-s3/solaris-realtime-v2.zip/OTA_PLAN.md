# Solaris OTA — plano seguro

A próxima etapa de OTA deve usar:

1. firmware assinado;
2. HTTPS para download;
3. validação de assinatura/hash antes de instalar;
4. partições A/B do ESP32;
5. rollback automático se o novo firmware não inicializar;
6. versão mínima permitida;
7. autenticação do servidor.

Não usar atualização de firmware por MQTT puro.

Fluxo:

Servidor de release
      ↓ HTTPS
ESP32-S3
      ↓ verificar assinatura
partição OTA_0/OTA_1
      ↓
boot seguro
      ↓
health check
      ↓
commit ou rollback
