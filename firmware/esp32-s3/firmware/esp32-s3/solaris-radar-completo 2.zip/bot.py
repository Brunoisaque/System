import os
import httpx
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

API_URL = os.getenv("SOLARIS_API_URL", "http://api:8000")
BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
API_USER = os.environ["SOLARIS_BOT_USER"]
API_PASS = os.environ["SOLARIS_BOT_PASS"]

async def api_login():
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.post(f"{API_URL}/auth/login", json={"username": API_USER, "password": API_PASS})
        r.raise_for_status()
        return r.json()["access_token"]

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🔴 Solaris Radar online.\n"
        "/weather — clima atual\n"
        "/scan escuro moderado — análise heurística\n"
        "/help — comandos"
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("/weather\n/scan <ceu> <vento> [gotas]\nEx.: /scan escuro moderado")

async def weather(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        token = await api_login()
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"{API_URL}/weather", headers={"Authorization": f"Bearer {token}"})
            r.raise_for_status()
            d = r.json()["current"]
        msg = (
            f"🌦️ Mauá/SP\n"
            f"🌡️ {d['temperature_2m']} °C\n"
            f"💧 Umidade: {d['relative_humidity_2m']}%\n"
            f"💨 Vento: {d['wind_speed_10m']} km/h\n"
            f"🌧️ Precipitação atual: {d['precipitation']} mm"
        )
        await update.message.reply_text(msg)
    except Exception:
        await update.message.reply_text("Não consegui consultar o serviço meteorológico agora.")

async def scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if len(args) < 2:
        await update.message.reply_text("Uso: /scan <ceu> <vento> [gotas]")
        return
    cloud, wind = args[0], args[1]
    drops = len(args) > 2 and args[2].lower() in {"gota", "gotas", "sim", "true"}
    token = await api_login()
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.post(
            f"{API_URL}/analyze",
            headers={"Authorization": f"Bearer {token}"},
            json={"cloud": cloud, "wind": wind, "drops": drops},
        )
        r.raise_for_status()
        result = r.json()["result"]
    await update.message.reply_text(f"🔎 {result['stage']}\n{result['message']}\nConfiança: {result['confidence']}")

app = Application.builder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("help", help_cmd))
app.add_handler(CommandHandler("weather", weather))
app.add_handler(CommandHandler("scan", scan))

if __name__ == "__main__":
    app.run_polling()
