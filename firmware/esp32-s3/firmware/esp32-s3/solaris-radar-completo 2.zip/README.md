# Solaris Radar — Bot + API

Projeto inicial real para monitoramento meteorológico e análise heurística de condições observadas.

## Arquitetura

Telegram Bot → FastAPI → Open-Meteo
                         ↘ SQLite

A API usa JWT e senhas com hash bcrypt. O bot não precisa acessar o banco diretamente.

## Subir localmente

1. Copie `.env.example` para `.env`.
2. Preencha os segredos.
3. Execute:

```bash
docker compose up --build -d
```

4. API:
   `http://localhost:8000/health`

5. Documentação:
   `http://localhost:8000/docs`

## Criar o usuário usado pelo bot

Com a API online:

```bash
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"solarisbot","password":"SUA_SENHA_FORTE"}'
```

Use a mesma senha em `SOLARIS_BOT_PASS`.

## Telegram

Crie um bot pelo BotFather, coloque o token em `.env` e reinicie:

```bash
docker compose up -d --build bot
```

Comandos:

- `/start`
- `/help`
- `/weather`
- `/scan escuro moderado`
- `/scan escuro forte gotas`

## GitHub

```bash
git init
git add .
git commit -m "feat: Solaris Radar API e Telegram bot"
git branch -M main
git remote add origin SEU_REPOSITORIO
git push -u origin main
```

## Segurança

- Nunca publique `.env`.
- Troque `JWT_SECRET` por um segredo aleatório forte.
- Em produção, coloque HTTPS/reverse proxy.
- Use PostgreSQL em vez de SQLite para implantação multiusuário.
- Restrinja CORS quando adicionar frontend.
- Não trate a heurística `/analyze` como previsão meteorológica: para previsão real, use os dados meteorológicos e radares oficiais.

## Próxima evolução

- PostgreSQL + Alembic
- Redis para cache
- WebSocket para eventos em tempo real
- autenticação OAuth2/OIDC
- dashboard web
- integração ESP32 via MQTT
- alertas baseados em previsão e radar
