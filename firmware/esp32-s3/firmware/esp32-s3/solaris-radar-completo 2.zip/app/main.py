import os
from datetime import datetime, timedelta, timezone
from typing import Optional

import httpx
from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from sqlalchemy import Boolean, Column, DateTime, Integer, String, create_engine
from sqlalchemy.orm import Session, declarative_base, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./solaris.db")
JWT_SECRET = os.getenv("JWT_SECRET", "change-this-in-production")
JWT_ALGORITHM = "HS256"
JWT_MINUTES = int(os.getenv("JWT_MINUTES", "60"))

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
pwd = CryptContext(schemes=["bcrypt"], deprecated="auto")
bearer = HTTPBearer()

app = FastAPI(title="Solaris Radar API", version="1.0.0")

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String(80), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

Base.metadata.create_all(engine)

class Credentials(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=8, max_length=128)

class Conditions(BaseModel):
    cloud: str = "clear"
    wind: str = "calm"
    drops: bool = False

def db():
    s = SessionLocal()
    try:
        yield s
    finally:
        s.close()

def make_token(username: str):
    exp = datetime.now(timezone.utc) + timedelta(minutes=JWT_MINUTES)
    return jwt.encode({"sub": username, "exp": exp}, JWT_SECRET, algorithm=JWT_ALGORITHM)

def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer), s: Session = Depends(db)):
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        username = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = s.query(User).filter(User.username == username, User.active == True).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

def classify(c: Conditions):
    if c.drops:
        return {"stage": "rain_started", "message": "Chuva já começou.", "confidence": "observed"}
    if c.cloud.lower() == "dark" and c.wind.lower() in {"moderate", "strong"}:
        return {"stage": "high_risk", "message": "Condições observadas são compatíveis com chuva iminente; confirme com radar oficial.", "confidence": "heuristic"}
    if c.cloud.lower() == "dark":
        return {"stage": "watch", "message": "Céu escuro: monitore radar e alertas oficiais.", "confidence": "heuristic"}
    return {"stage": "normal", "message": "Sem sinal suficiente para afirmar chuva iminente.", "confidence": "heuristic"}

@app.get("/health")
def health():
    return {"status": "ok", "service": "solaris-radar"}

@app.post("/auth/register")
def register(c: Credentials, s: Session = Depends(db)):
    if s.query(User).filter(User.username == c.username).first():
        raise HTTPException(409, "Username already exists")
    u = User(username=c.username, password_hash=pwd.hash(c.password))
    s.add(u); s.commit()
    return {"created": True}

@app.post("/auth/login")
def login(c: Credentials, s: Session = Depends(db)):
    u = s.query(User).filter(User.username == c.username).first()
    if not u or not pwd.verify(c.password, u.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    return {"access_token": make_token(u.username), "token_type": "bearer"}

@app.get("/me")
def me(u: User = Depends(current_user)):
    return {"username": u.username}

@app.post("/analyze")
def analyze(c: Conditions, u: User = Depends(current_user)):
    return {"user": u.username, "result": classify(c), "timestamp": datetime.now(timezone.utc)}

@app.get("/weather")
async def weather(lat: float = -23.667, lon: float = -46.461, u: User = Depends(current_user)):
    # Mauá/SP defaults. Data source: Open-Meteo public forecast API.
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat, "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m",
        "hourly": "precipitation_probability,precipitation,weather_code",
        "forecast_days": 2, "timezone": "America/Sao_Paulo"
    }
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        return r.json()
