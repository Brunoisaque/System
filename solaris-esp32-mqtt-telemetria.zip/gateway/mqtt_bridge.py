import json
import os
import httpx
import paho.mqtt.client as mqtt

MQTT_HOST = os.getenv("MQTT_HOST", "localhost")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_TOPIC = os.getenv("MQTT_TOPIC", "solaris/telemetry")
SOLARIS_API = os.getenv("SOLARIS_API", "http://localhost:8000")

def on_connect(client, userdata, flags, rc, properties=None):
    print("MQTT connected:", rc)
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        print("Telemetry:", payload)

        # Optional forwarding to the Solaris API.
        # Keep this disabled until the API endpoint is deployed.
        # httpx.post(f"{SOLARIS_API}/telemetry", json=payload, timeout=5)

    except Exception as exc:
        print("Invalid telemetry:", exc)

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_HOST, MQTT_PORT, 60)
client.loop_forever()
