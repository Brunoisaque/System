#include <WiFi.h>
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_AHTX0.h>
#include <ArduinoJson.h>

const char* WIFI_SSID = "YOUR_WIFI";
const char* WIFI_PASS = "YOUR_PASSWORD";

const char* MQTT_HOST = "192.168.1.100";
const uint16_t MQTT_PORT = 1883;
const char* MQTT_USER = "solaris";
const char* MQTT_PASS = "CHANGE_ME";

const char* DEVICE_ID = "solaris-esp32s3-01";
const char* TOPIC_TELEMETRY = "solaris/telemetry";
const char* TOPIC_STATUS = "solaris/status";
const char* TOPIC_COMMAND = "solaris/command";

WiFiClient net;
PubSubClient mqtt(net);
Adafruit_AHTX0 aht;

unsigned long lastPublish = 0;
const unsigned long PUBLISH_MS = 2000;

void connectWiFi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
  }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  if (String(topic) != TOPIC_COMMAND) return;

  StaticJsonDocument<256> cmd;
  if (deserializeJson(cmd, payload, length)) return;

  const char* action = cmd["action"] | "";
  if (String(action) == "ping") {
    mqtt.publish(TOPIC_STATUS, "{\"device\":\"solaris-esp32s3-01\",\"status\":\"pong\"}");
  }
}

void connectMQTT() {
  while (!mqtt.connected()) {
    String clientId = String(DEVICE_ID) + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (mqtt.connect(clientId.c_str(), MQTT_USER, MQTT_PASS)) {
      mqtt.subscribe(TOPIC_COMMAND);
      mqtt.publish(TOPIC_STATUS, "{\"status\":\"online\"}", true);
    } else {
      delay(2000);
    }
  }
}

void publishTelemetry() {
  sensors_event_t humidity, temp;
  aht.getEvent(&humidity, &temp);

  StaticJsonDocument<512> doc;
  doc["device_id"] = DEVICE_ID;
  doc["uptime_ms"] = millis();
  doc["wifi_rssi"] = WiFi.RSSI();
  doc["temperature_c"] = temp.temperature;
  doc["humidity_pct"] = humidity.relative_humidity;
  doc["free_heap"] = ESP.getFreeHeap();

  char payload[512];
  serializeJson(doc, payload, sizeof(payload));
  mqtt.publish(TOPIC_TELEMETRY, payload);
}

void setup() {
  Serial.begin(115200);
  Wire.begin();

  if (!aht.begin()) {
    Serial.println("AHT20 not found");
  }

  connectWiFi();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMQTT();

  mqtt.loop();

  if (millis() - lastPublish >= PUBLISH_MS) {
    lastPublish = millis();
    publishTelemetry();
  }
}
