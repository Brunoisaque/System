# Solaris ESP32-S3 + MQTT + Telemetria

Módulo inicial de telemetria em tempo real.

## Fluxo

ESP32-S3 + AHT20
        ↓ Wi-Fi
Mosquitto MQTT
        ↓
Gateway Python
        ↓
Solaris API

## Hardware inicial

- ESP32-S3
- AHT20/AHT21 para temperatura + umidade
- cabo USB
- Wi-Fi

Sensores adicionais podem ser conectados depois.

## Firmware

Abra `firmware/solaris_esp32_s3.ino` na Arduino IDE.

Instale:

- ESP32 Arduino Core
- PubSubClient
- ArduinoJson
- Adafruit AHTX0

Configure:

- WIFI_SSID
- WIFI_PASS
- MQTT_HOST
- MQTT_USER
- MQTT_PASS

O ESP32 publica a cada 2 segundos em:

`solaris/telemetry`

Formato:

```json
{
  "device_id": "solaris-esp32s3-01",
  "uptime_ms": 12345,
  "wifi_rssi": -52,
  "temperature_c": 24.1,
  "humidity_pct": 68.2,
  "free_heap": 221000
}
```

## MQTT local

Para laboratório, o Mosquitto está configurado sem autenticação.

**Não exponha essa porta diretamente à internet.** Em produção, use usuário/senha, TLS e firewall.

Subir:

```bash
docker compose -f docker-compose.mqtt.yml up --build -d
```

Teste:

```bash
mosquitto_sub -h localhost -t solaris/telemetry -v
```

## Próxima etapa

Conectar o gateway ao endpoint de telemetria do Solaris Radar, armazenar séries temporais e criar WebSocket/dashboard.

Depois podemos adicionar:

- MAX30102
- BMP280/BME280
- IMU
- sensor de luz
- bateria
- BLE
- OTA
- inferência TinyML no ESP32-S3
